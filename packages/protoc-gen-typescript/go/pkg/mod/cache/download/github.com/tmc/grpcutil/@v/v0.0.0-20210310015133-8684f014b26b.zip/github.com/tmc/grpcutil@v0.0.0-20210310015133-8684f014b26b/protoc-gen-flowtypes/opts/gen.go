//go:generate protoc --go_out=. opts.proto

package opts
