//go:generate protoc -I. -I$GOOGLEAPIS_ROOT --go_out=. opts.proto

package opts
