// Package genelmtypes provides a code generator for elm types.
package genelmtypes
