// Package genflowtypes provides a code generator for flow types.
package genflowtypes
